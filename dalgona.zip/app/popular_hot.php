<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8"/>
  <link rel="stylesheet" type="text/css" href="css/popular_hot.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script type="text/javascript" src="js/popular_hot.js"></script>
</head>
<body>
  <input type=hidden id=id value="<?=$_GET['id']?>">
  <div id=header>
    <img id=header_background src="img/gradient.png">
    <img id=header_dalgona src="img/img_logo_90x120.png">
    <p id=header_title>달고나</p>
  </div>
  <div id=notice>
    <p id=notice_text>달고나와 함께하는 인기핫 어플들을 설치 해 보세요!</p>
  </div>
  <div id=content>
    <!--
    <div id=line>
      <center>
        <div id=app_image>
          <img src="img/btn_write_134x134.png" width="40px">
        </div>
        <div id=app_descript>
          <p id=app_descript_text>은밀한 채팅<br><font style='font-size:10px;'>더이상 구애 받지 말고 연애하세요! 프리하게!</font></p>
        </div>
        <div id=app_install_btn>
          <img src="img/btn_install_112x72.png" width="50px">
        </div>
      </center>
    </div>
  -->
  </div>
</body>
</html>
