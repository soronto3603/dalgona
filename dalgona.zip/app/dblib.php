<?
	$db_host ="localhost";
	$db_user="total0808";
	$db_passwd="top41567720";
	$db_name="total0808";
?>
