<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <script type="text/javascript" src="js/user.js"></script>
</head>
<body id=content>
  <!--<table>
    <tr>
      <th>no</th><th>닉네임</th><th>나이</th><th>번호</th><th>성별</th><th></th>
    </tr>
    <tr>
      <td>1</td><td>아무개</td><td>22</td><td>01058837630</td><td>여자</td><td><button>수정</button><button>삭제</button></td>
    </tr>
  </table>-->
</body>
</html>
