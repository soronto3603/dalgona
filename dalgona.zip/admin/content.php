<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <script type="text/javascript" src="js/content.js"></script>
</head>
<body id=content_box>
  <h1>게시물 관리</h1>
  <button onclick="open_page(1)">달고나 게시판</button>
  <button onclick="open_page(2)">자유 게시판</button>
</body>
</html>
