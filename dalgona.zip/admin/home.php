<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <center style="font-size: 80px;margin-top: 50px;margin-right: 200px;">관리자 페이지</center>
</body>
</html>
