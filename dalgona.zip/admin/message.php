<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/index.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <script type="text/javascript" src="js/message.js"></script>
</head>
<body>
  <h1 style="font-size:80px">공지관리</h1>
  <h1 style="font-size:40px">공지글</h1>
  <h2>40자를 안넘기는 것이 줄바꿈이 생기지 않아 보기 좋습니다.</h2>
  <input id=message style="width:500px;"><button onclick="update_message()">등록</button>
  <!--<h1 style="font-size:40px">URL</h1>
  <input id=url style="width:500px;"><button onclick="update_message()">등록</button>-->
</body>
</html>
